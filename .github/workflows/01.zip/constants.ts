
import { ContentSection, Person, Experiment, TimelineEvent, UnitDivision, BranchUnit, TrialRecord } from './types.ts';

export const IMAGES = {
    HERO: 'https://upload.wikimedia.org/wikipedia/commons/a/af/A_close_up_photo_of_the_Unit_731_square_building_taken_by_the_aviation_and_photography_class_of_Unit_731_in_1940.jpg',
    BUILDING_SITE: 'https://upload.wikimedia.org/wikipedia/commons/thumb/c/ca/Building_on_the_site_of_the_Harbin_bioweapon_facility_of_Unit_731_%E9%96%A2%E6%9D%B1%E8%BB%8D%E9%98%B2%E7%96%AB%E7%B5%A6%E6%B0%B4%E9%83%A8%E6%9C%AC%E9%83%A8731%E9%83%A8%E9%9A%8A%EF%BC%88%E7%9F%B3%E4%BA%95%E9%83%A8%E9%9A%8A%EF%BC%89%E6%97%A5%E8%BB%8D%E7%AC%AC731%E9%83%A8%E9%9A%8A%E6%97%A7%E5%9D%80_PB121201.JPG/1024px-Building_on_the_site_of_the_Harbin_bioweapon_facility_of_Unit_731_%E9%96%A2%E6%9D%B1%E8%BB%8D%E9%98%B2%E7%96%AB%E7%B5%A6%E6%B0%B4%E9%83%A8%E6%9C%AC%E9%83%A8731%E9%83%A8%E9%9A%8A%EF%BC%88%E7%9F%B3%E4%BA%95%E9%83%A8%E9%9A%8A%EF%BC%89%E6%97%A5%E8%BB%8D%E7%AC%AC731%E9%83%A8%E9%9A%8A%E6%97%A7%E5%9D%80_PB121201.JPG',
    BOILER_RUINS: 'https://upload.wikimedia.org/wikipedia/commons/thumb/6/6f/Building_on_the_site_of_the_Harbin_bioweapon_facility_of_Unit_731_%E9%96%A2%E6%9D%B1%E8%BB%8D%E9%98%B2%E7%96%AB%E7%B5%A6%E6%B0%B4%E9%83%A8%E6%9C%AC%E9%83%A8731%E9%83%A8%E9%9A%8A%EF%BC%88%E7%9F%B3%E4%BA%95%E9%83%A8%E9%9A%8A%EF%BC%89%E6%97%A5%E8%BB%8D%E7%AC%AC731%E9%83%A8%E9%9A%8A%E6%97%A7%E5%9D%80_PB121178a_%E3%83%9C%E3%82%A4%E3%83%A9%E3%83%BC%E6%A5%9D%E8%B7%A1.JPG/1024px-thumbnail.jpg',
    FROSTBITE_DATA: 'https://upload.wikimedia.org/wikipedia/commons/thumb/7/72/Scan_Of_Yoshimura_Hisato%27s_Frostbite_Research_Data.png/1024px-Scan_Of_Yoshimura_Hisato%27s_Frostbite_Research_Data.png',
    CELL_SKETCH: 'https://upload.wikimedia.org/wikipedia/commons/thumb/5/53/A_sketch_of_the_prison_cells%2C_done_by_a_member_of_Unit_731._The_octagonal_sketch_represents_the_pressure_chamber.jpg/1280px-A_sketch_of_the_prison_cells%2C_done_by_a_member_of_Unit_731._The_octagonal_sketch_represents_the_pressure_chamber.jpg',
    DESTRUCTION: 'https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/A_photograph_of_the_Unit_731_square_building_taken_during_its_destruction_in_1945.jpg/1024px-A_photograph_of_the_Unit_731_square_building_taken_during_its_destruction_in_1945.jpg',
    MUSEUM: 'https://upload.wikimedia.org/wikipedia/commons/d/dd/Main_entrance_of_Harbin%27s_Unit_731_Museum.jpg',
    COMPLEX: 'https://upload.wikimedia.org/wikipedia/commons/b/bc/Unit_731_-_Complex.jpg',
    ISHII: 'https://upload.wikimedia.org/wikipedia/commons/a/ae/Shiro-ishii.jpg',
    NAITO: 'https://upload.wikimedia.org/wikipedia/commons/3/31/Ry%C5%8Dichi_Nait%C5%8D.png',
    YOSHIMURA: 'https://upload.wikimedia.org/wikipedia/commons/9/91/Yoshimura_Hisato.jpg',
};

// Section 1: Introduction
export const INTRO_SECTION: ContentSection = {
  title: '黑暗深渊',
  subtitle: '何为731部队？',
  paragraphs: [
    '731部队，全称为“满洲第731部队”，是日本帝国陆军一支隐匿在历史帷幕后的秘密部队。在第二次中日战争和第二次世界大战期间，它以“防疫和给水净化”为伪装，实则从事着人类历史上最骇人听闻的生物战和化学战研究。',
    '这支由石井四郎中将领导的部队，在中国哈尔滨市的平房区建立了一个庞大的基地，系统性地对活人进行惨无人道的实验。受害者被剥夺姓名、尊严，并被非人化地称为“原木”（Maruta）。他们在这里经历了疾病注射、活体解剖、极端环境测试和武器效能验证，最终无一幸免。',
    '据不完全统计，至少有3,000名囚犯（主要是中国和俄罗斯人）在731部队的实验中直接遇害。更为严重的是，其开发的生物武器被用于实战，导致了中国至少20万平民的死亡。这不仅是战争罪行，更是对人类文明和道德底线的彻底践踏。'
  ],
  layout: 'center',
};

// Section 2: Timeline
export const TIMELINE_EVENTS: TimelineEvent[] = [
    { year: "1925年", title: "日内瓦议定书", description: "《日内瓦议定书》禁止在战争中使用生物和化学武器。日本签署但未批准，并认为该禁令反而证明了其作为武器的有效性，从而加速了相关研究。" },
    { year: "1931年", title: "九一八事变", description: "日本侵占中国东北，建立了伪满洲国。这片土地为日本建立秘密研究基地提供了条件，远离本土，且能轻易获取大量的“实验材料”。" },
    { year: "1932年", title: "“东乡部队”与“石井网络”", description: "石井四郎在东京的陆军军医学校成立“防疫研究室”，并组织秘密研究小组“东乡部队”，开始在满洲进行化学和生物实验，标志着“石井网络”的开端。" },
    { year: "1936年", title: "731部队正式成立", description: "根据裕仁天皇的敕令，部队扩编并正式命名为“关东军防疫给水部”，即731部队。其前身是设在哈尔滨以南百公里的“中马城”实验场，该设施因囚犯暴动和爆炸而被废弃。" },
    { year: "1940年", title: "细菌战的实施", description: "731部队开始大规模生产鼠疫、炭疽等病菌，并对中国多个城市发动细菌战。例如，在宁波和常德，通过飞机投撒携带鼠疫杆菌的跳蚤，引发大规模瘟疫。" },
    { year: "1945年8月", title: "毁灭证据与末日逃亡", description: "苏联出兵中国东北，日本战败在即。731部队接到命令，销毁所有证据。他们炸毁了平房基地的大部分建筑，屠杀了剩余的全部囚犯，并命令所有成员“将秘密带入坟墓”。" }
];

// Section 3: Structure
export const STRUCTURE_TITLE_SECTION = {
    title: "恶魔的巢穴",
    subtitle: "一个庞大而精密的杀人网络"
};

export const DIVISIONS: UnitDivision[] = [
    { name: "第一部 (研究)", description: "核心部门，使用活人进行鼠疫、霍乱、炭疽、伤寒和结核病等细菌研究。为此设有一座可容纳约400人的特别监狱。" },
    { name: "第二部 (实战)", description: "研究生物武器的实战应用，特别是开发和制造用于散播细菌和寄生虫的装置，如陶瓷炸弹。" },
    { name: "第三部 (生产)", description: "负责生产装有生物制剂的炮弹，驻扎在哈尔滨。" },
    { name: "第四部 (制造)", description: "负责大规模生产细菌等生物战剂并储存。" },
    { name: "第五部 (训练)", description: "负责培训人员，向新成员传授进行人体实验和生物战的“知识”与“技能”。" },
    { name: "第六至八部", description: "分别是设备、医疗和行政部门，为整个部队的运转提供后勤支持。" }
];

export const BRANCH_UNITS: BranchUnit[] = [
    { name: "满洲第100部队", location: "长春", description: "与731部队并列，主要研究针对动物和植物的细菌武器，也进行人体实验。" },
    { name: "北京第1855部队", location: "北京", description: "华北地区的主要分支，进行鼠疫、霍乱等细菌研究和人体实验。" },
    { name: "南京第1644部队 (荣字部队)", location: "南京", description: "华中地区的主要分支，同样进行细菌生产和人体实验，并将病菌投入水源。" },
    { name: "广州第8604部队 (波字部队)", location: "广州", description: "华南地区的主要分支，负责细菌战研究和实施。" },
    { name: "新加坡第9420部队 (冈字部队)", location: "新加坡", description: "东南亚地区的分支，研究热带地区的传染病并进行细菌战准备。" }
];

// Section 4: Victims
export const VICTIMS_SECTION: ContentSection = {
    title: "“原木”",
    subtitle: "被剥夺人性的受害者",
    paragraphs: [
        '在731部队的内部，被用于实验的活人被剥夺了姓名和身份，获得一个三位数的编号，并被蔑称为“Maruta”（マルタ，意为“原木”）。这个词源于部队对外的伪装——“木材厂”，也暗示了这些生命在实验者眼中，如同木头一样没有知觉，可以随意砍伐、处理。',
        '受害者来源广泛，绝大多数是中国人，包括抗日游击队员、情报人员、平民，甚至妇女、儿童和婴儿。此外，还有大量俄罗斯人、蒙古人和朝鲜人。他们被日本宪兵队以“间谍”或“可疑分子”的罪名逮捕，秘密送往平房基地。',
        '他们被关押在被称为“木屋”的牢房里，受到严密监视。为了保证实验“数据”的“纯净”，他们会得到相对充足的食物，以维持健康的身体状态，直到被送入实验室。没有任何记录表明，曾有任何一名“原木”活着离开了这个人间地狱。'
    ],
    image: IMAGES.CELL_SKETCH,
    imageAlt: "731部队囚室手绘图",
    layout: 'text-left'
};

// Section 5: Experiments
export const EXPERIMENTS_TITLE_SECTION = {
    title: "科学的暴行",
    subtitle: "在实验室中进行的系统性屠杀"
};

export const EXPERIMENTS: Experiment[] = [
    {
        title: "活体解剖",
        description: "为了观察疾病在人体内的发展过程，研究人员在不使用任何麻醉剂的情况下，对感染了各种病菌的活人进行解剖。受害者在极度痛苦和清醒中被剖开身体，直至死亡。一名部队前成员回忆道：“当我拿起手术刀时，他开始尖叫……他发出了难以想象的声音，然后就停止了。”",
        details: [
            "受害者包括男性、女性、儿童，甚至有从孕妇体内取出的胎儿。",
            "器官被摘除用于病理研究，尸体则被直接送入焚尸炉。",
            "前部队军医汤浅谦承认，这种活体解剖在侵华日军中是“常规操作”，主要用于“练习”外科技术。"
        ]
    },
    {
        title: "冻伤实验",
        description: "由吉村寿人主导，目的是为在严寒地区作战的日军研究冻伤的治疗方法。囚犯被带到零下几十度的户外，将手臂或腿部反复浸入冰水中，直至完全冻僵。然后，研究人员用木棍敲打冻硬的肢体，测试其反应，并尝试各种“解冻”方法，如浸泡在不同温度的水中，甚至直接用火烤。",
        quote: "“（冻僵的肢体）发出的声音，就像木板被敲击时一样。” — 731部队成员证词",
        details: [
            "实验记录显示，受害者遭受了极大的痛苦，常常导致肌肉组织坏死、骨肉分离。",
            "吉村寿人甚至对一名出生仅三天的婴儿进行过冻伤实验。",
            "这些残忍的实验数据，后来被他以“对猴子的研究”为名，发表在学术期刊上。"
        ]
    },
    {
        title: "生物武器测试",
        description: "为了测试细菌武器的杀伤力，囚犯被当作活靶。他们被绑在空旷场地的木桩上，然后日军从不同距离引爆装有炭疽、鼠疫或坏疽菌的炸弹。研究人员身穿防护服，在爆炸后走近垂死的受害者，检查和记录他们的伤口和症状。",
        details: [
            "手榴弹、火焰喷射器、化学武器等常规武器也同样在活人身上进行测试。",
            "一些囚犯被施以不同程度的创伤，然后进行手术，以研究战地外伤的治疗方法。"
        ]
    },
    {
        title: "病菌感染与传播",
        description: "通过注射、口服或吸入等方式，向囚犯故意传播鼠疫、霍乱、伤寒、炭疽、梅毒等多种病原体，以研究疾病的发病机制、病程和致死率。为了研究性病的传播，部队甚至强迫健康的囚犯与患病的囚犯发生性关系。",
        details: [
            "部队成员将感染了梅毒的女囚称为“果酱面包”。",
            "在实验中出生的婴儿也未能幸免，被用于研究疾病的母婴传播。",
            "大量实验数据记录了不同血型之间输血的排异反应。"
        ]
    },
    {
        title: "极端环境实验",
        description: "除了上述实验，731部队还进行了多种挑战人类生存极限的残酷测试。例如，将囚犯关进压力舱中，逐渐加压，直到他们的眼球因巨大压力而弹出；将人活活吊死、用重物压死、电死或活埋；将人绑在离心机上高速旋转直至死亡；以及在不提供食物和水的情况下，记录其走向死亡的全过程。",
        details: [
            "在脱水实验中，受害者被置于高温干燥的房间内，直至身体水分完全丧失，变成一具“木乃伊”，体重仅为原来的五分之一。"
        ]
    }
];

// Section 6: Biowarfare
export const BIOWARFARE_SECTION: ContentSection = {
  title: '潘多拉之盒',
  subtitle: '散播死亡的细菌战',
  paragraphs: [
    '731部队的罪恶远不止于实验室。石井四郎的核心目标是发展能大规模使用的生物武器。他们将实验室的成果应用到真实战场，对中国平民和城市发动了多次惨无人道的细菌攻击。',
    '部队培育了数以亿计的携带鼠疫杆菌的跳蚤，并将它们与谷物、棉花等混合，装入特别设计的陶瓷炸弹中。这些炸弹由飞机低空投掷到宁波、常德、衢州等城市。炸弹在空中爆裂后，受感染的跳蚤和物资散落各处，迅速引发了毁灭性的鼠疫大流行。',
    '此外，他们还将伤寒、霍乱等病菌直接投放到水井、河流、水库和食物中，制造人为的疫情。据中国方面的估计，日本的细菌战在中国至少造成了20万至30万平民的死亡。这种以平民为目标的无差别攻击，是现代战争史上最卑劣的战争罪行之一。'
  ],
  image: IMAGES.BOILER_RUINS,
  imageAlt: '731部队锅炉房遗址，这里曾为细菌生产提供动力',
  layout: 'text-right',
};

// Section 7: Key People & Trials
export const KEY_PEOPLE_TITLE_SECTION = {
    title: "恶魔的面孔",
    subtitle: "主导罪行的元凶与战后的审判"
};

export const KEY_PEOPLE: Person[] = [
  { name: '石井四郎', title: '731部队创建者和指挥官', image: IMAGES.ISHII },
  { name: '北野政次', title: '1942-1945年指挥官', image: IMAGES.ISHII }, // placeholder image
  { name: '吉村寿人', title: '冻伤实验主要负责人', image: IMAGES.YOSHIMURA },
  { name: '内藤良一', title: '主要成员，战后创立绿十字药企', image: IMAGES.NAITO },
];

export const TRIAL_RECORDS: TrialRecord[] = [
    { name: "山田乙三", position: "关东军总司令", unit: "731, 100", sentence: "25年劳动改造" },
    { name: "梶塚隆二", position: "关东军医务处长", unit: "731", sentence: "25年劳动改造" },
    { name: "高桥隆笃", position: "关东军兽医处长", unit: "731", sentence: "25年劳动改造" },
    { name: "川岛清", position: "731部队生产部长", unit: "731", sentence: "25年劳动改造" },
    { name: "柄泽十三夫", position: "731部队科长", unit: "731", sentence: "20年劳动改造" },
    { name: "西俊英", position: "731部队分队长", unit: "731", sentence: "18年劳动改造" },
];

// Section 8: Cover-up
export const LEGACY_SECTION: ContentSection = {
  title: '被掩盖的真相',
  subtitle: '罪恶的豁免与战后遗毒',
  paragraphs: [
    '1945年8月，随着苏联红军进入中国东北，731部队的末日来临。石井四郎下令销毁所有证据，包括炸毁核心设施、焚烧研究文件，以及屠杀所有在押的“原木”。',
    '然而，这场罪恶并未随着战争的结束而得到清算。战后，美国为了在与苏联的冷战中获得生物战的技术优势，与石井四郎及其下属达成了一项肮脏的交易。美国调查人员，如细菌学专家默里·桑德斯中校，以豁免战争罪为条件，换取了731部队用数千条人命换来的实验数据。',
    '因此，当德国纳粹医生在纽伦堡接受审判时，731部队的主要战犯却逃脱了正义的惩罚。石井四郎安度晚年，其他许多成员则摇身一变，成为日本医学界、学术界、商界乃至政界的精英。例如，内藤良一创立了后来曝出血液污染丑闻的知名药企“绿十字”。这段历史被刻意地掩盖和遗忘，成为了人类司法史上的一大污点。'
  ],
  image: IMAGES.DESTRUCTION,
  imageAlt: '1945年被炸毁的731部队主楼',
  layout: 'text-left',
};

// Section 9: Closing
export const CLOSING_SECTION = {
    title: "以史为鉴，警钟长鸣",
    image: IMAGES.MUSEUM,
    imageAlt: "哈尔滨731部队罪证陈列馆入口"
};
