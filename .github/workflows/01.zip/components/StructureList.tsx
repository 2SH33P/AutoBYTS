
import React from 'react';
import { UnitDivision, BranchUnit } from '../types.ts';
import AnimatedSection from './AnimatedSection.tsx';

interface StructureListProps {
  divisions: UnitDivision[];
  branches: BranchUnit[];
}

const StructureList: React.FC<StructureListProps> = ({ divisions, branches }) => {
  return (
    <div className="w-full grid grid-cols-1 lg:grid-cols-2 gap-x-16 gap-y-12">
      <AnimatedSection>
        <h3 className="text-4xl font-bold mb-8 border-b-2 border-neutral-700 pb-4">核心部门</h3>
        <div className="space-y-8">
          {divisions.map((division, index) => (
            <div key={index} className="pl-4 border-l-4 border-red-400/50">
              <h4 className="text-2xl font-semibold">{division.name}</h4>
              <p className="text-neutral-300 mt-1 font-light text-lg">{division.description}</p>
            </div>
          ))}
        </div>
      </AnimatedSection>
      <AnimatedSection>
        <h3 className="text-4xl font-bold mb-8 border-b-2 border-neutral-700 pb-4">主要分支网络</h3>
        <div className="space-y-8">
          {branches.map((branch, index) => (
            <div key={index} className="pl-4 border-l-4 border-neutral-700">
              <h4 className="text-2xl font-semibold">{branch.name} <span className="text-lg font-normal text-neutral-500">({branch.location})</span></h4>
              <p className="text-neutral-300 mt-1 font-light text-lg">{branch.description}</p>
            </div>
          ))}
        </div>
      </AnimatedSection>
    </div>
  );
};

export default StructureList;
