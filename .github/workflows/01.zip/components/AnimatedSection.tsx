
import React, { ReactNode } from 'react';
import { useInView } from '../hooks/useInView.ts';

interface AnimatedSectionProps {
  children: ReactNode;
  className?: string;
  style?: React.CSSProperties;
}

const AnimatedSection: React.FC<AnimatedSectionProps> = ({ children, className = '', style }) => {
  const [ref, isInView] = useInView<HTMLDivElement>({
    triggerOnce: true,
    threshold: 0.1,
  });

  return (
    <div
      ref={ref}
      style={style}
      className={`transition-all duration-1000 ease-out ${isInView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'} ${className}`}
    >
      {children}
    </div>
  );
};

export default AnimatedSection;
