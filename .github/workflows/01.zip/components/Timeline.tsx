
import React from 'react';
import { TimelineEvent } from '../types.ts';
import AnimatedSection from './AnimatedSection.tsx';

interface TimelineProps {
  events: TimelineEvent[];
}

const Timeline: React.FC<TimelineProps> = ({ events }) => {
  return (
    <div className="relative border-l-2 border-neutral-700 ml-6 md:ml-0">
      {events.map((event, index) => (
        <AnimatedSection key={index} className="mb-16">
          <div className="flex items-start">
            <div className="absolute w-5 h-5 bg-red-400 rounded-full -left-[11px] mt-1 border-4 border-black"></div>
            <div className="pl-10">
              <span className="text-xl font-bold text-neutral-400">{event.year}</span>
              <h4 className="text-3xl font-bold mt-1 mb-2">{event.title}</h4>
              <p className="text-lg text-neutral-300 font-light">{event.description}</p>
            </div>
          </div>
        </AnimatedSection>
      ))}
    </div>
  );
};

export default Timeline;
