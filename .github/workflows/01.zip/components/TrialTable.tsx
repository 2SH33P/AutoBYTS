
import React from 'react';
import { TrialRecord } from '../types.ts';

interface TrialTableProps {
  records: TrialRecord[];
  title: string;
  subtitle: string;
}

const TrialTable: React.FC<TrialTableProps> = ({ records, title, subtitle }) => {
  return (
    <div className="w-full">
        <div className="text-center mb-12">
            <h3 className="text-2xl md:text-3xl font-semibold text-neutral-400 mb-4">{subtitle}</h3>
            <h2 className="text-5xl md:text-7xl font-bold">{title}</h2>
        </div>
        <div className="overflow-x-auto rounded-lg border border-neutral-800 bg-neutral-900/50 backdrop-blur-sm">
            <table className="min-w-full">
                <thead className="bg-neutral-800/70">
                <tr>
                    <th scope="col" className="px-6 py-4 text-left text-sm font-semibold text-neutral-300 uppercase tracking-wider">姓名</th>
                    <th scope="col" className="px-6 py-4 text-left text-sm font-semibold text-neutral-300 uppercase tracking-wider">职位</th>
                    <th scope="col" className="px-6 py-4 text-left text-sm font-semibold text-neutral-300 uppercase tracking-wider">所属部队</th>
                    <th scope="col" className="px-6 py-4 text-left text-sm font-semibold text-neutral-300 uppercase tracking-wider">判决 (哈巴罗夫斯克审判)</th>
                </tr>
                </thead>
                <tbody className="divide-y divide-neutral-800">
                {records.map((record, index) => (
                    <tr key={index} className="hover:bg-neutral-800/50 transition-colors duration-200">
                    <td className="px-6 py-4 whitespace-nowrap text-md font-medium text-neutral-100">{record.name}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-md text-neutral-300">{record.position}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-md text-neutral-300">{record.unit}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-md text-neutral-300">{record.sentence}</td>
                    </tr>
                ))}
                </tbody>
            </table>
        </div>
        <p className="text-center text-sm text-neutral-500 mt-4">注：苏联在哈巴罗夫斯克（伯力）审判了12名731部队成员，而美国则对石井四郎等主要战犯给予了豁免。所有被苏方判刑的战犯最晚于1956年均已返回日本。</p>
    </div>
  );
};

export default TrialTable;
