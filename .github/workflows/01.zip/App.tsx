
import React from 'react';
import AnimatedSection from './components/AnimatedSection.tsx';
import Timeline from './components/Timeline.tsx';
import TrialTable from './components/TrialTable.tsx';
import StructureList from './components/StructureList.tsx';
import {
  INTRO_SECTION,
  TIMELINE_EVENTS,
  STRUCTURE_TITLE_SECTION, DIVISIONS, BRANCH_UNITS,
  VICTIMS_SECTION,
  EXPERIMENTS, EXPERIMENTS_TITLE_SECTION,
  BIOWARFARE_SECTION,
  KEY_PEOPLE, KEY_PEOPLE_TITLE_SECTION, TRIAL_RECORDS,
  LEGACY_SECTION,
  CLOSING_SECTION,
  IMAGES
} from './constants.ts';
import { ContentSection, Person, Experiment } from './types.ts';

const SectionHeader: React.FC<{ title: string; subtitle?: string }> = ({ title, subtitle }) => (
    <div className="text-center">
        {subtitle && <h3 className="text-2xl md:text-3xl font-semibold text-neutral-400 mb-4">{subtitle}</h3>}
        <h2 className="text-5xl md:text-7xl font-bold">{title}</h2>
    </div>
);

const ContentBlock: React.FC<{ section: ContentSection }> = ({ section }) => {
  const layoutClasses = {
    'center': 'flex-col text-center',
    'text-left': 'flex-col lg:flex-row items-center',
    'text-right': 'flex-col lg:flex-row-reverse items-center',
    'image-full': 'flex-col'
  };

  const textAlignment = section.layout === 'center' ? 'text-center' : 'text-left';

  return (
    <div className={`flex ${layoutClasses[section.layout]} gap-12 w-full`}>
      {section.image && section.layout !== 'image-full' && (
        <div className="lg:w-1/2 w-full flex-shrink-0">
          <img src={section.image} alt={section.imageAlt} className="rounded-lg object-cover w-full h-full shadow-2xl shadow-black/50" />
        </div>
      )}
      <div className={`${section.image && section.layout !== 'image-full' ? 'lg:w-1/2' : ''} w-full ${textAlignment}`}>
        {section.subtitle && <h3 className="text-2xl md:text-3xl font-semibold text-neutral-400 mb-4">{section.subtitle}</h3>}
        <h2 className="text-4xl md:text-6xl font-bold mb-8">{section.title}</h2>
        <div className="space-y-6 text-lg md:text-xl text-neutral-300 font-light">
          {section.paragraphs.map((p, i) => <p key={i}>{p}</p>)}
        </div>
      </div>
    </div>
  );
};

const ExperimentsGrid: React.FC<{ experiments: Experiment[] }> = ({ experiments }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
      {experiments.map((exp, index) => (
        <div key={index} className="bg-neutral-900/50 p-6 rounded-lg border border-neutral-800 flex flex-col">
          <h4 className="text-3xl font-bold text-red-300 mb-3">{exp.title}</h4>
          <p className="text-lg text-neutral-300 font-light flex-grow">{exp.description}</p>
          {exp.quote && <p className="text-md text-neutral-500 italic mt-4 border-l-2 border-neutral-600 pl-4">"{exp.quote}"</p>}
        </div>
      ))}
    </div>
  );
};

const App: React.FC = () => {
  return (
    <div className="bg-black text-neutral-100 leading-relaxed">
      <header
        className="h-screen w-full flex flex-col justify-center items-center text-center p-4 relative bg-cover bg-center"
        style={{ backgroundImage: `url(${IMAGES.HERO})` }}
      >
        <div className="absolute inset-0 bg-black opacity-60"></div>
        <div className="relative z-10">
          <h1 className="text-6xl md:text-9xl font-extrabold tracking-tighter">731部队</h1>
          <p className="text-2xl md:text-4xl text-neutral-300 mt-4 font-light">不能忘记的罪恶</p>
        </div>
      </header>

      <main className="flex flex-col items-center space-y-32 md:space-y-48 py-24 md:py-32 px-4 sm:px-6 lg:px-8">
        
        <AnimatedSection className="w-full container mx-auto max-w-4xl">
           <ContentBlock section={INTRO_SECTION} />
        </AnimatedSection>
        
        <AnimatedSection className="w-full container mx-auto max-w-4xl">
            <SectionHeader title="罪恶的源起" subtitle="一段黑暗历史的时间轴" />
            <div className="mt-16">
                <Timeline events={TIMELINE_EVENTS} />
            </div>
        </AnimatedSection>
        
        <AnimatedSection className="w-full container mx-auto">
            <SectionHeader {...STRUCTURE_TITLE_SECTION} />
            <div className="mt-16">
                <StructureList divisions={DIVISIONS} branches={BRANCH_UNITS} />
            </div>
        </AnimatedSection>

        <AnimatedSection className="w-full h-[60vh] md:h-[80vh] bg-cover bg-center bg-fixed rounded-lg shadow-2xl shadow-black/50" style={{ backgroundImage: `url(${IMAGES.COMPLEX})` }}>
            <div className="w-full h-full flex items-end justify-center p-8 bg-black/40">
                <p className="text-lg text-white font-semibold text-center bg-black/50 px-4 py-2 rounded">731部队位于哈尔滨平房区的庞大建筑群鸟瞰图，一个与世隔绝的杀人工厂。</p>
            </div>
        </AnimatedSection>

        <AnimatedSection className="w-full container mx-auto">
          <ContentBlock section={VICTIMS_SECTION} />
        </AnimatedSection>

        <div className="w-full container mx-auto flex flex-col items-center space-y-16">
          <AnimatedSection>
              <SectionHeader {...EXPERIMENTS_TITLE_SECTION} />
          </AnimatedSection>
          <AnimatedSection className="w-full">
             <ExperimentsGrid experiments={EXPERIMENTS} />
          </AnimatedSection>
        </div>
        
        <AnimatedSection className="w-full container mx-auto">
          <div className="w-full h-auto md:h-[60vh] bg-neutral-900 p-4 md:p-8 rounded-lg flex flex-col items-center justify-center">
            <img src={IMAGES.FROSTBITE_DATA} alt="冻伤实验数据" className="max-w-full max-h-[85%] object-contain rounded-md" />
            <p className="text-center text-sm text-neutral-500 mt-4">吉村寿人发表的冻伤实验数据，为了掩盖真相，受害者在论文中被称为“满洲猴子”。</p>
          </div>
        </AnimatedSection>
        
        <AnimatedSection className="w-full container mx-auto">
          <ContentBlock section={BIOWARFARE_SECTION} />
        </AnimatedSection>

        <AnimatedSection className="w-full container mx-auto">
            <TrialTable records={TRIAL_RECORDS} title={KEY_PEOPLE_TITLE_SECTION.title} subtitle={KEY_PEOPLE_TITLE_SECTION.subtitle} />
        </AnimatedSection>

        <AnimatedSection className="w-full container mx-auto">
          <ContentBlock section={LEGACY_SECTION} />
        </AnimatedSection>

        <AnimatedSection className="w-full container mx-auto flex flex-col items-center text-center">
            <div className="w-full max-w-5xl mb-8">
                <img src={CLOSING_SECTION.image} alt={CLOSING_SECTION.imageAlt} className="rounded-lg object-cover w-full h-full shadow-2xl shadow-black/50" />
            </div>
            <h2 className="text-4xl md:text-6xl font-bold">{CLOSING_SECTION.title}</h2>
        </AnimatedSection>

      </main>

      <footer className="text-center py-12 border-t border-neutral-800 px-4">
        <p className="text-neutral-500">内容主要参考自 Wikipedia - Unit 731 词条及相关学术资料。</p>
        <p className="text-neutral-600 text-sm mt-2">这是一个非商业性、以教育和警示为目的的项目。铭记历史，珍爱和平。</p>
      </footer>
    </div>
  );
}

export default App;
