
export interface ContentSection {
  title: string;
  subtitle?: string;
  paragraphs: string[];
  image?: string;
  imageAlt?: string;
  layout: 'center' | 'text-left' | 'text-right' | 'image-full';
}

export interface Person {
  name: string;
  title: string;
  image: string;
}

export interface Experiment {
    title: string;
    description: string;
    details?: string[];
    quote?: string;
}

export interface TimelineEvent {
    year: string;
    title:string;
    description: string;
}

export interface UnitDivision {
    name: string;
    description: string;
}

export interface BranchUnit {
    name: string;
    location: string;
    description: string;
}

export interface TrialRecord {
    name: string;
    position: string;
    unit: string;
    sentence: string;
}
