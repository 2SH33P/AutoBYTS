import { useState, useEffect, useRef, MutableRefObject } from 'react';

// Define an options type that includes our custom property `triggerOnce`
interface UseInViewOptions extends IntersectionObserverInit {
  triggerOnce?: boolean;
}

// Update the hook to accept the new options type
export const useInView = <T extends Element,>(options?: UseInViewOptions): [MutableRefObject<T | null>, boolean] => {
  const ref = useRef<T | null>(null);
  const [isInView, setIsInView] = useState(false);

  useEffect(() => {
    // Separate our custom option from the standard IntersectionObserver options
    const { triggerOnce, ...observerOptions } = options || {};

    const observer = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting) {
        setIsInView(true);
        // If `triggerOnce` is true, we unobserve the element after it becomes visible
        if (triggerOnce) {
          observer.unobserve(entry.target);
        }
      } else {
        // Optional: if you want the animation to reverse when scrolling out
        // For a "trigger once" animation, we don't want to set it back to false.
        // setIsInView(false);
      }
    }, observerOptions); // Pass only the standard options to the constructor

    const currentRef = ref.current;
    if (currentRef) {
      observer.observe(currentRef);
    }

    return () => {
      if (currentRef) {
        observer.unobserve(currentRef);
      }
    };
  }, [ref, options]); // Keep the dependency array as it was to maintain original behavior

  return [ref, isInView];
};
